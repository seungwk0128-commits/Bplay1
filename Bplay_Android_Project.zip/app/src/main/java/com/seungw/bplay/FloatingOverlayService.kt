package com.seungw.bplay
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
class FloatingOverlayService:Service(){
 private lateinit var wm:WindowManager; private lateinit var v:View
 override fun onCreate(){super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager
  v=LayoutInflater.from(this).inflate(R.layout.layout_floating_ui,null)
  val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
   if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
   WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
  p.gravity=Gravity.TOP or Gravity.START;p.x=100;p.y=100;wm.addView(v,p)
  v.findViewById<Button>(R.id.btnStop).setOnClickListener{stopService(Intent(this,GPSMockService::class.java));stopSelf()}
 }
 override fun onStartCommand(i:Intent?,f:Int,s:Int):Int{v.findViewById<TextView>(R.id.tvDistance).text="${i?.getDoubleExtra("MOVED",0.0)?.div(1000)} km / ${i?.getDoubleExtra("TOTAL",0.0)?.div(1000)} km";v.findViewById<TextView>(R.id.tvPercent).text="${i?.getIntExtra("PERCENT",0)}%";return START_NOT_STICKY}
 override fun onDestroy(){if(::v.isInitialized)wm.removeView(v);super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}