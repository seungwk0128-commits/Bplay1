package com.seungw.bplay
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.net.Uri
import android.widget.*
class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  val code=DeviceCodeGenerator.getFixedDeviceCode(this)
  findViewById<TextView>(R.id.tvCode).text="기기 코드: $code"
  findViewById<Button>(R.id.btnReady).setOnClickListener{
   if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))}
   else startService(Intent(this,FloatingOverlayService::class.java))
  }
  DiscordWebhookManager.sendApprovalRequest(code)
 }
}