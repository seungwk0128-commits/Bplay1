package com.seungw.bplay
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import kotlin.concurrent.thread
object DiscordWebhookManager {
 private const val WEBHOOK_URL = "REPLACE_WITH_YOUR_DISCORD_WEBHOOK"
 fun sendApprovalRequest(code:String){ thread {
  try {
   val c=URL(WEBHOOK_URL).openConnection() as HttpURLConnection
   c.requestMethod="POST"; c.setRequestProperty("Content-Type","application/json"); c.doOutput=true
   val json="""{"username":"Bplay Auth Bot","content":"새 Bplay 승인 요청: `$code`"}"""
   OutputStreamWriter(c.outputStream).use{it.write(json)}
   c.responseCode
  } catch(_:Exception){}
 }}
}