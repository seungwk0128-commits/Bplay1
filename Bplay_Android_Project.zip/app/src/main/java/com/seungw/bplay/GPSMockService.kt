package com.seungw.bplay
import android.app.Service
import android.content.Intent
import android.os.IBinder
class GPSMockService:Service(){
 override fun onStartCommand(i:Intent?,f:Int,s:Int):Int{ if(i?.action=="ACTION_STOP") stopSelf(); return START_NOT_STICKY }
 override fun onBind(i:Intent?):IBinder?=null
}