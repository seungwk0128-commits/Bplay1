package com.seungw.bplay
object SecurityCheck { fun isDebuggable():Boolean=false }