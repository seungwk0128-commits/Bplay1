package com.seungw.bplay
import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
object DeviceCodeGenerator {
 fun getFixedDeviceCode(context: Context): String {
  val id=Settings.Secure.getString(context.contentResolver,Settings.Secure.ANDROID_ID)?:"BPLAYDEFAULT"
  val bytes=MessageDigest.getInstance("SHA-256").digest(id.toByteArray())
  var l=""; var d=""
  for(b in bytes){ val v=b.toInt() and 255
   if(l.length<4) l+=('A'.code+v%26).toChar()
   else if(d.length<4) d+=(v%10)
   if(l.length==4&&d.length==4) break
  }
  return "BPLAY-$l$d"
 }
}